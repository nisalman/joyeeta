<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class movie extends Model
{
    //
}
